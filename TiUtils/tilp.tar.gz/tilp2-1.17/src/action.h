#include <gtk/gtk.h>


gint display_action_dbox(gchar * dst_folder);

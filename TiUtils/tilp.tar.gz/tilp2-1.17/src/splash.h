#include <gtk/gtk.h>

void splash_screen_set_label(gchar * label);
GtkWidget *splash_screen_start();
void splash_screen_stop(void);

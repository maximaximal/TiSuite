#include <gtk/gtk.h>


gint display_properties_dbox(const char *filename);

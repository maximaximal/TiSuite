#include <gtk/gtk.h>

gint display_clock_dbox();

#include <gtk/gtk.h>


gint display_manpage_dbox();

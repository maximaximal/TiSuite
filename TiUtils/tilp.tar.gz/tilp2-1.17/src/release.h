#include <gtk/gtk.h>

gint display_release_dbox(void);

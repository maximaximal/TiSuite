#include <gtk/gtk.h>

gint display_options_dbox();

#include <gtk/gtk.h>


gint display_about_dbox();

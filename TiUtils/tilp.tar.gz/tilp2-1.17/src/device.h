#include <gtk/gtk.h>

gint display_device_dbox();

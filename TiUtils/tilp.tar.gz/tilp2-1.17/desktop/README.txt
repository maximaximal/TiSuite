This directory contains FreeDesktop.org Desktop and MIME types definitions for TILP.

If your desktop environment doesn't detect the files after `make install`, run:
* `update-desktop-database`;
* `update-mime-database [YOUR_INSTALL_PREFIX, e.g. /usr]/share/mime > /dev/null`.
